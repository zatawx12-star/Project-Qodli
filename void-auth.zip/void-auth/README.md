# VOID Auth — Login & Register System

Sistem autentikasi profesional dengan desain dark futuristic yang dioptimalkan untuk Gen Z.

---

## 📁 Struktur Folder

```
void-auth/
├── index.html              # Markup utama
├── README.md               # Dokumentasi ini
│
├── css/
│   ├── variables.css       # Design tokens & CSS custom properties
│   ├── base.css            # Reset & base styles
│   ├── layout.css          # Background, wrapper, card, logo
│   ├── components.css      # Tabs, buttons, toast, alert, social
│   ├── forms.css           # Input, label, strength meter, checkbox
│   ├── dashboard.css       # Dashboard: avatar, stats, badge
│   └── animations.css      # Semua @keyframes
│
└── js/
    ├── db.js               # Database layer (localStorage abstraction)
    ├── utils.js            # Validasi, hashing, helper functions
    ├── auth.js             # Logic login, register, logout, session
    ├── ui.js               # DOM helpers, alert, toast, dashboard render
    └── app.js              # Entry point & event listeners
```

---

## 🚀 Cara Menjalankan

### Lokal
Cukup buka `index.html` langsung di browser. Tidak memerlukan server atau build tool.

### Dengan Live Server (VS Code)
1. Install ekstensi **Live Server**
2. Klik kanan `index.html` → **Open with Live Server**

---

## ✨ Fitur

### UI / UX
- Dark theme dengan animated gradient orbs
- Grid overlay + noise texture untuk depth
- Font Syne (display) + DM Sans (body)
- Tab switcher animasi Login ↔ Register
- Micro-interactions: input focus glow, hover, button press
- Fully responsive (mobile-first)

### Autentikasi
- **Register**: validasi lengkap, cek duplikat email & username real-time
- **Login**: autentikasi dengan password hash, update login count
- **Session**: auto-restore sesi saat halaman di-refresh
- **Logout**: hapus sesi & kembali ke halaman login
- Password strength meter (4 level: Terlalu lemah → Kuat)
- Toggle show/hide password
- Social login button (placeholder)
- Forgot password (placeholder)

### Database
- Berbasis `localStorage` — cocok untuk demo & prototyping
- API abstraksi bersih di `js/db.js` agar mudah diganti backend nyata

---

## 🔒 Catatan Keamanan (Produksi)

| Fitur | Demo | Produksi |
|-------|------|----------|
| Penyimpanan | localStorage | PostgreSQL / MongoDB |
| Hash password | Simulasi client-side | bcrypt / argon2 (server-side) |
| Session | localStorage | JWT + HttpOnly Cookie |
| Social Login | Placeholder | OAuth 2.0 (Google, GitHub) |
| HTTPS | Tidak wajib lokal | **Wajib** |

---

## 🛠 Tech Stack

- **HTML5** — Semantik, aksesibel
- **CSS3** — Custom properties, Grid, Flexbox, animasi
- **Vanilla JS** — ES6+, async/await, modular
- **Google Fonts** — Syne + DM Sans

---

## 📦 Dependensi Eksternal

- [Google Fonts](https://fonts.google.com) — CDN, tidak perlu instalasi

---

## 🎨 Design System

| Token | Nilai |
|-------|-------|
| `--accent` | `#8264ff` (ungu) |
| `--accent2` | `#ff5fa0` (pink) |
| `--accent3` | `#5fffc8` (cyan) |
| `--bg` | `#050507` |
| `--surface` | `#0e0e14` |
| `--font-display` | Syne |
| `--font-body` | DM Sans |

---

Made with ❤️ by VOID
