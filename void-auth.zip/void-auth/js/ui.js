/**
 * VOID Auth — UI Helpers & DOM Interactions
 * js/ui.js
 */

/* ============================================================
   TAB SWITCHER
   ============================================================ */

/**
 * Switch between the Login and Register tabs.
 * @param {'login'|'register'} tab
 */
function switchTab(tab) {
  const tabBtns = document.querySelectorAll('.tab-btn');
  const forms   = document.querySelectorAll('.form');

  tabBtns.forEach(b => b.classList.remove('active'));
  forms.forEach(f => f.classList.remove('active'));

  document.getElementById('form-' + tab).classList.add('active');
  document.getElementById('form-alert').classList.remove('show');

  tabBtns[tab === 'login' ? 0 : 1].classList.add('active');
}

/* ============================================================
   ALERT BOX
   ============================================================ */

/** @type {number|null} */
let alertTimer = null;

/**
 * Display an inline alert inside the card.
 * @param {string}           msg
 * @param {'error'|'success'} type
 */
function showAlert(msg, type = 'error') {
  const el    = document.getElementById('form-alert');
  const icon  = document.getElementById('alert-icon');
  const msgEl = document.getElementById('alert-msg');

  el.className = 'alert ' + type + ' show';
  icon.textContent  = type === 'error' ? '⚠' : '✓';
  msgEl.textContent = msg;

  if (alertTimer) clearTimeout(alertTimer);
  alertTimer = setTimeout(() => el.classList.remove('show'), 4000);
}

/* ============================================================
   TOAST
   ============================================================ */

/** @type {number|null} */
let toastTimer = null;

/**
 * Show a floating toast notification.
 * @param {string}            msg
 * @param {'success'|'error'} type
 */
function showToast(msg, type = 'success') {
  const toast = document.getElementById('toast');
  document.getElementById('toast-msg').textContent = msg;
  toast.className = 'toast ' + type + ' show';

  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 3000);
}

/* ============================================================
   LOADING STATE
   ============================================================ */

/**
 * Enable or disable the loading state on a submit button.
 * @param {string}  btnId
 * @param {boolean} state
 */
function setLoading(btnId, state) {
  const btn = document.getElementById(btnId);
  btn.disabled = state;
  state
    ? btn.classList.add('loading')
    : btn.classList.remove('loading');
}

/* ============================================================
   TOGGLE PASSWORD VISIBILITY
   ============================================================ */

/**
 * Toggle an input between text / password type.
 * @param {string}      inputId — id of the input element
 * @param {HTMLElement} btn     — the eye-button that was clicked
 */
function togglePw(inputId, btn) {
  const input = document.getElementById(inputId);
  if (input.type === 'password') {
    input.type    = 'text';
    btn.textContent = '🙈';
  } else {
    input.type    = 'password';
    btn.textContent = '👁';
  }
}

/* ============================================================
   PASSWORD STRENGTH METER
   ============================================================ */

/**
 * Evaluate password strength and update the strength meter UI.
 * @param {HTMLInputElement} input
 */
function checkStrength(input) {
  const val   = input.value;
  const wrap  = document.getElementById('strength-wrap');
  const label = document.getElementById('strength-label');
  const bars  = ['sb1', 'sb2', 'sb3', 'sb4'].map(id => document.getElementById(id));

  if (!val) {
    wrap.classList.remove('show');
    return;
  }

  wrap.classList.add('show');

  // Score criteria
  let score = 0;
  if (val.length >= 8)             score++;   // length
  if (/[A-Z]/.test(val))           score++;   // uppercase
  if (/[0-9]/.test(val))           score++;   // digit
  if (/[^A-Za-z0-9]/.test(val))    score++;   // special char

  const labels = ['Terlalu lemah', 'Lemah', 'Cukup', 'Kuat'];
  label.textContent = labels[score - 1] || 'Terlalu lemah';

  bars.forEach((bar, i) => {
    bar.className = 'strength-bar';
    if (i < score) bar.classList.add('filled-' + score);
  });
}

/* ============================================================
   USERNAME AVAILABILITY CHECK
   ============================================================ */

/**
 * Highlight the username input if the username is already taken.
 * @param {HTMLInputElement} input
 */
function checkUsername(input) {
  const taken = !!DB.findUserByUsername(input.value);
  input.style.borderColor = taken ? 'var(--error)' : '';
}

/* ============================================================
   DASHBOARD RENDER
   ============================================================ */

/**
 * Populate and reveal the dashboard view.
 * @param {Object} user — user record from DB
 */
function showDashboard(user) {
  // Hide auth, show dashboard
  document.getElementById('auth-wrapper').classList.add('hide');
  document.getElementById('dashboard').classList.add('show');

  // Avatar initials
  const initials = (
    (user.firstName?.[0] || '') +
    (user.lastName?.[0]  || '')
  ).toUpperCase();

  document.getElementById('dash-avatar').textContent = initials;
  document.getElementById('dash-name').textContent   = user.firstName + ' ' + (user.lastName || '');
  document.getElementById('dash-email').textContent  = user.email;

  // Stats
  const joinYear = new Date(user.joinedAt).getFullYear();
  document.getElementById('stat-joined').textContent = joinYear;
  document.getElementById('stat-logins').textContent = user.loginCount || 1;
  document.getElementById('stat-users').textContent  = DB.userCount();
}
