/**
 * VOID Auth — Database Layer
 * js/db.js
 *
 * Abstraction over localStorage.
 * In production, replace these with real API calls to your backend.
 */

const DB = {
  /** Keys */
  KEYS: {
    USERS:   'void_users',
    SESSION: 'void_session',
  },

  /**
   * Get all registered users.
   * @returns {Array} Array of user objects.
   */
  getUsers() {
    return JSON.parse(localStorage.getItem(this.KEYS.USERS) || '[]');
  },

  /**
   * Persist the users array to storage.
   * @param {Array} users
   */
  saveUsers(users) {
    localStorage.setItem(this.KEYS.USERS, JSON.stringify(users));
  },

  /**
   * Find a single user by email.
   * @param {string} email
   * @returns {Object|undefined}
   */
  findUserByEmail(email) {
    return this.getUsers().find(u => u.email === email.toLowerCase());
  },

  /**
   * Find a single user by username.
   * @param {string} username
   * @returns {Object|undefined}
   */
  findUserByUsername(username) {
    return this.getUsers().find(u => u.username === username.toLowerCase());
  },

  /**
   * Add a new user to the database.
   * @param {Object} user
   */
  createUser(user) {
    const users = this.getUsers();
    users.push(user);
    this.saveUsers(users);
  },

  /**
   * Update an existing user record.
   * @param {string} email  — lookup key
   * @param {Object} patch  — fields to update
   */
  updateUser(email, patch) {
    const users = this.getUsers();
    const idx   = users.findIndex(u => u.email === email.toLowerCase());
    if (idx !== -1) {
      users[idx] = { ...users[idx], ...patch };
      this.saveUsers(users);
    }
  },

  /**
   * Get the current session.
   * @returns {Object|null}
   */
  getSession() {
    return JSON.parse(localStorage.getItem(this.KEYS.SESSION) || 'null');
  },

  /**
   * Persist a session object.
   * @param {Object} session
   */
  saveSession(session) {
    localStorage.setItem(this.KEYS.SESSION, JSON.stringify(session));
  },

  /**
   * Destroy the current session (logout).
   */
  clearSession() {
    localStorage.removeItem(this.KEYS.SESSION);
  },

  /**
   * Total number of registered users.
   * @returns {number}
   */
  userCount() {
    return this.getUsers().length;
  },
};
