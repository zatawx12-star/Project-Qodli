/**
 * VOID Auth — Utility Functions
 * js/utils.js
 */

/* ============================================================
   VALIDATION
   ============================================================ */

/**
 * Check if an email address is well-formed.
 * @param {string} email
 * @returns {boolean}
 */
function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/**
 * Check if a username is valid (3-20 chars, alphanumeric + underscore).
 * @param {string} username
 * @returns {boolean}
 */
function validateUsername(username) {
  return /^[a-zA-Z0-9_]{3,20}$/.test(username);
}

/* ============================================================
   SECURITY HELPERS
   ============================================================ */

/**
 * Lightweight client-side password hash simulation.
 *
 * ⚠️  FOR DEMO PURPOSES ONLY.
 *     In production, hashing MUST happen server-side with bcrypt / argon2.
 *
 * @param {string} password  — raw password
 * @returns {string}          — hashed string
 */
function hashPassword(password) {
  let h = 0;
  for (let i = 0; i < password.length; i++) {
    h = (Math.imul(31, h) + password.charCodeAt(i)) | 0;
  }
  return 'hashed_' + Math.abs(h).toString(16) + '_' + password.length;
}

/* ============================================================
   MISC HELPERS
   ============================================================ */

/**
 * Return a promise that resolves after `ms` milliseconds.
 * Used to simulate realistic network latency in the demo.
 * @param {number} ms
 * @returns {Promise<void>}
 */
function simulateDelay(ms = 1200) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Generate a simple unique ID.
 * @returns {string}
 */
function generateId() {
  return 'uid_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
}
