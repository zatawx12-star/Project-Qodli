/**
 * VOID Auth — Authentication Logic
 * js/auth.js
 *
 * Handles: login, register, logout, and session restoration.
 */

/* ============================================================
   LOGIN
   ============================================================ */

async function handleLogin() {
  const email    = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  const remember = document.getElementById('remember-me').checked;

  // --- Client-side validation ---
  if (!email || !password) {
    showAlert('Email dan password wajib diisi!');
    return;
  }
  if (!validateEmail(email)) {
    showAlert('Format email tidak valid.');
    return;
  }

  setLoading('btn-login', true);
  await simulateDelay(1000); // Simulate network request

  // --- Database lookup ---
  const user = DB.findUserByEmail(email);

  if (!user) {
    showAlert('Akun tidak ditemukan. Coba daftar dulu!');
    setLoading('btn-login', false);
    return;
  }

  if (user.password !== hashPassword(password)) {
    showAlert('Password salah. Coba lagi!');
    setLoading('btn-login', false);
    return;
  }

  // --- Update login stats ---
  const loginCount = (user.loginCount || 0) + 1;
  DB.updateUser(email, {
    loginCount,
    lastLogin: new Date().toISOString(),
  });

  // --- Persist session ---
  DB.saveSession({
    email:     user.email,
    username:  user.username,
    firstName: user.firstName,
    lastName:  user.lastName,
    joinedAt:  user.joinedAt,
    loginCount,
    remember,
  });

  setLoading('btn-login', false);
  showToast('Selamat datang kembali, ' + user.firstName + '! 🎉');

  // Show dashboard after brief toast display
  setTimeout(() => showDashboard({ ...user, loginCount }), 800);
}

/* ============================================================
   REGISTER
   ============================================================ */

async function handleRegister() {
  const firstName = document.getElementById('reg-firstname').value.trim();
  const lastName  = document.getElementById('reg-lastname').value.trim();
  const username  = document.getElementById('reg-username').value.trim().toLowerCase();
  const email     = document.getElementById('reg-email').value.trim().toLowerCase();
  const password  = document.getElementById('reg-password').value;
  const confirm   = document.getElementById('reg-confirm').value;
  const agreed    = document.getElementById('agree-terms').checked;

  // --- Client-side validation ---
  if (!firstName || !lastName || !username || !email || !password || !confirm) {
    showAlert('Semua field wajib diisi!');
    return;
  }
  if (!validateEmail(email)) {
    showAlert('Format email tidak valid.');
    return;
  }
  if (!validateUsername(username)) {
    showAlert('Username 3-20 karakter, hanya huruf, angka & underscore.');
    return;
  }
  if (password.length < 8) {
    showAlert('Password minimal 8 karakter.');
    return;
  }
  if (password !== confirm) {
    showAlert('Konfirmasi password tidak cocok!');
    return;
  }
  if (!agreed) {
    showAlert('Kamu harus menyetujui Syarat & Kebijakan.');
    return;
  }

  setLoading('btn-register', true);
  await simulateDelay(1200); // Simulate network request

  // --- Duplicate checks ---
  if (DB.findUserByEmail(email)) {
    showAlert('Email sudah terdaftar. Coba login!');
    setLoading('btn-register', false);
    return;
  }
  if (DB.findUserByUsername(username)) {
    showAlert('Username sudah dipakai. Coba yang lain!');
    setLoading('btn-register', false);
    return;
  }

  // --- Create user record ---
  const newUser = {
    id:         generateId(),
    firstName,
    lastName,
    username,
    email,
    password:   hashPassword(password),
    joinedAt:   new Date().toISOString(),
    loginCount: 1,
    lastLogin:  new Date().toISOString(),
  };

  DB.createUser(newUser);

  // --- Create session ---
  DB.saveSession({
    email:     newUser.email,
    username:  newUser.username,
    firstName: newUser.firstName,
    lastName:  newUser.lastName,
    joinedAt:  newUser.joinedAt,
    loginCount: 1,
  });

  setLoading('btn-register', false);
  showToast('Akun berhasil dibuat! Selamat bergabung 🚀');
  setTimeout(() => showDashboard(newUser), 800);
}

/* ============================================================
   LOGOUT
   ============================================================ */

function handleLogout() {
  DB.clearSession();
  document.getElementById('dashboard').classList.remove('show');
  document.getElementById('auth-wrapper').classList.remove('hide');
  switchTab('login');
  showToast('Kamu berhasil keluar. Sampai jumpa! 👋');
}

/* ============================================================
   SESSION RESTORE
   ============================================================ */

/**
 * Called on page load. If a valid session exists, skip the auth
 * screen and go straight to the dashboard.
 */
function restoreSession() {
  const session = DB.getSession();
  if (!session) return;

  const user = DB.findUserByEmail(session.email);
  if (user) {
    showDashboard(user);
  } else {
    // Session references a deleted user — clean it up
    DB.clearSession();
  }
}

/* ============================================================
   SOCIAL LOGIN (placeholder)
   ============================================================ */

function socialLogin(provider) {
  showToast(`Integrasi ${provider} belum tersedia dalam demo ini 😄`, 'error');
}

/* ============================================================
   FORGOT PASSWORD (placeholder)
   ============================================================ */

function forgotPw(event) {
  event.preventDefault();
  const email = document.getElementById('login-email').value.trim();
  if (!email) {
    showAlert('Masukkan email kamu dulu, ya!');
    return;
  }
  showToast('Link reset dikirim ke ' + email + ' (simulasi)', 'success');
}
