/**
 * VOID Auth — App Entry Point
 * js/app.js
 *
 * Bootstraps the application: attaches global event listeners
 * and restores any existing user session.
 */

/* ============================================================
   KEYBOARD SHORTCUTS
   ============================================================ */

/**
 * Allow users to submit the active form by pressing Enter.
 */
document.addEventListener('keydown', function (event) {
  if (event.key !== 'Enter') return;

  const activeForm = document.querySelector('.form.active');
  if (!activeForm) return;

  if (activeForm.id === 'form-login') {
    handleLogin();
  } else if (activeForm.id === 'form-register') {
    handleRegister();
  }
});

/* ============================================================
   INIT
   ============================================================ */

/**
 * Run on page load.
 * Checks for an existing session and skips the auth screen
 * if one is found.
 */
(function init() {
  restoreSession();
})();
