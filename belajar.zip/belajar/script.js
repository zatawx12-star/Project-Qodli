// ================= PAGE TRANSITION =================
window.addEventListener("DOMContentLoaded", () => {
  document.body.classList.add("fade-in");

  document.querySelectorAll("a[href]").forEach(link => {
    link.addEventListener("click", function(e) {
      const href = this.getAttribute("href");

      if (href && !href.startsWith("http") && !href.startsWith("#")) {
        e.preventDefault();
        document.body.classList.remove("fade-in");

        setTimeout(() => {
          window.location.href = href;
        }, 300);
      }
    });
  });
});

window.onload = function () {

const videos = [

/* ================= FRONTEND (12) ================= */
{category:"frontend", sesi:"1. BELAJAR MEMBUAT WEBSITE DARI 0", url:"https://youtu.be/71a2zeC71gk"},
{category:"frontend", sesi:"2. IMPLEMENTASI LOGIKA SEDERHANA", url:"https://youtu.be/Mb6Np6QURDY"},
{category:"frontend", sesi:"3. BOOTSTRAP UNTUK PEMULA", url:"https://youtu.be/igwNyjc7Ii8"},
{category:"frontend", sesi:"4. CETREKAN LAMPU", url:"https://youtu.be/vQeJIa-ZYm4"},
{category:"frontend", sesi:"5. LOCAL STORAGE BROWSER", url:"https://youtu.be/QUpyv31Nyso"},
{category:"frontend", sesi:"6. (Dark Mode) SAMPAI PUBLISH KE REPLIT", url:"https://youtu.be/QIpWKTHKcqM"},
{category:"frontend", sesi:"7. BACKEND (NodeJs) UNTUK PEMULA", url:"https://youtu.be/kLUI9LISP5k"},
{category:"frontend", sesi:"8. WEB GENERATOR PASSWORD", url:"https://youtu.be/XqJYMlCpYQA"},
{category:"frontend", sesi:"9. CUSTOM VIDEO PLAYER SEDERHANA", url:"https://youtu.be/nK8CxPxv8wY"},
{category:"frontend", sesi:"10. PERSIAPAN SEMESTER 2", url:"https://youtu.be/8r0xK50HhNY"},
{category:"frontend", sesi:"11. UBAH BACKGROUND MENGGUNAKAN JAVASCRIPT SEDERHANA", url:"https://youtu.be/H3NreO2ICVM"},
{category:"frontend", sesi:"12. PUBLISH WEBSITE JADI ONLINE", url:"https://youtu.be/pXHkqQz8xlE"},

/* ================= REACT (5) ================= */
{category:"react", sesi:"1. PENDAHULUAN", url:"https://youtu.be/kcnwI_5nKyA"},
{category:"react", sesi:"2. INSTALASI & KONFIGURASI", url:"https://youtu.be/RVH_5L5Lsp0"},
{category:"react", sesi:"3. MEMBUAT GAME TIC TAC TOE", url:"https://youtu.be/Ji8lAuohopk"},
{category:"react", sesi:"4. MEMBUAT APP CATATAN BELANJA", url:"https://youtu.be/HX2kAHnCEjY"},
{category:"react", sesi:"5. SEMUA TENTANG COMPONENT", url:"https://youtu.be/-9Z9a91vTLc"},

/* ================= NODE (24) ================= */
{category:"node", sesi:"1. APA ITU NODEJS?", url:"https://youtu.be/sSLJx5t4OJ4"},
{category:"node", sesi:"2. ARSITEKTUR NODEJS", url:"https://youtu.be/wcQaspZE-20"},
{category:"node", sesi:"3. INSTALASI & KONFIGURASI", url:"https://youtu.be/VfN1_pEdQAA"},
{category:"node", sesi:"4. REPL", url:"https://youtu.be/74a8L0HZE-Q"},
{category:"node", sesi:"5. MENJALANKAN FILE NODEJS", url:"https://youtu.be/Fa2BggXYE24"},
{category:"node", sesi:"6. NODEJS MODULE SYSTEM", url:"https://youtu.be/9hT29YQuB2U"},
{category:"node", sesi:"7. NODEJS CORE MODULES", url:"https://youtu.be/PzjGJFUjms4"},
{category:"node", sesi:"8. APA ITU NPM", url:"https://youtu.be/WVHkBuiCcIs"},
{category:"node", sesi:"9. MENGGUNAKAN PACKAGE NPM", url:"https://youtu.be/XT2Vvs_KgTI"},
{category:"node", sesi:"10. MEMBUAT CONTACT APP (1)", url:"https://youtu.be/IXyMKLIGf6Y"},
{category:"node", sesi:"11. MEMBUAT CONTACT APP (2)", url:"https://youtu.be/3zX5VmbOHxk"},
{category:"node", sesi:"12. MEMBUAT CONTACT APP (3)", url:"https://youtu.be/ZR2X1mlAkcU"},
{category:"node", sesi:"13. NODEJS WEB SERVER", url:"https://youtu.be/sN49luguIrc"},
{category:"node", sesi:"14. APA ITU EXPRESS JS", url:"https://youtu.be/TecGUz4bPFA"},
{category:"node", sesi:"15. EXPRESS VIEW ENGINE", url:"https://youtu.be/5VM5NGje2W8"},
{category:"node", sesi:"16. EXPRESS MIDDLEWARE", url:"https://youtu.be/IDeVryWnXFw"},
{category:"node", sesi:"17. EXPRESS CONTACT APP (1)", url:"https://youtu.be/8cVWOdcWUu0"},
{category:"node", sesi:"18. EXPRESS CONTACT APP (2)", url:"https://youtu.be/eu4uwmyHMHo"},
{category:"node", sesi:"19. EXPRESS CONTACT APP (3)", url:"https://youtu.be/xrYD_IhmuTM"},
{category:"node", sesi:"20. APA ITU MONGODB", url:"https://youtu.be/Jfw9c0C0Zt8"},
{category:"node", sesi:"21. INSTALASI & KONFIGURASI MONGODB", url:"https://youtu.be/iXhmi0NYdc8"},
{category:"node", sesi:"22. MONGODB DAN NODEJS", url:"https://youtu.be/oUFyCpIl6tA"},
{category:"node", sesi:"23. MONGODB CONTACT APP [Menggunakan Mongoose] (1)", url:"https://youtu.be/E3FRqyu5s_4"},
{category:"node", sesi:"24. MONGODB CONTACT APP [Menggunakan Mongoose] (2)", url:"https://youtu.be/iL6zhc3HZuw"},

/* ================= PYTHON (6) ================= */
{category:"python", sesi:"1. PRAKTEK DASAR", url:"https://youtu.be/n0tURC_xeyI"},
{category:"python", sesi:"2. FUNDAMENTAL LOGIKA", url:"https://youtu.be/XtYprke-rpA"},
{category:"python", sesi:"3. FUNCTION & LOOPING IMPLEMENTATION", url:"https://youtu.be/gZ6DPx16Odw"},
{category:"python", sesi:"4. SIMPLE CODE CLEANING", url:"https://youtu.be/GayBjV2NxQo"},
{category:"python", sesi:"5. FACE DETECTION OPENCV", url:"https://youtu.be/51XVxq8Rhv4"},
{category:"python", sesi:"6. DATABASE MYSQL", url:"https://youtu.be/eKruXIX6LZk"},

/* ================= C++ (29) ================= */
{category:"cpp", sesi:"1. PENDAHULUAN", url:"https://youtu.be/ZYBkuY1eiZ4"},
{category:"cpp", sesi:"2A. SETUP VISUAL CODE STUDIO PADA WINDOWS", url:"https://youtu.be/4-PyiuVaYRc"},
{category:"cpp", sesi:"2B. SETUP VISUAL CODE STUDIO PADA MACOS", url:"https://youtu.be/2OytybOco8U"},
{category:"cpp", sesi:"2C. SETUP VISUAL CODE STUDIO PADA UBUNTU", url:"https://youtu.be/o1x9OoaEO-M"},
{category:"cpp", sesi:"3. CLASS & OBJECT", url:"https://youtu.be/-hjM06S5g10"},
{category:"cpp", sesi:"4. CONSTRUCTOR", url:"https://youtu.be/cPC_eRTz2dw"},
{category:"cpp", sesi:"5. METHODS", url:"https://youtu.be/qYl3tM2mtYc"},
{category:"cpp", sesi:"6. LATIHAN MEMBUAT DATABASE", url:"https://youtu.be/d-MKNuVn0zE"},
{category:"cpp", sesi:"7. BERBAGAI CARA MEMBUAT OBJECT", url:"https://youtu.be/LaFxsl8rhTs"},
{category:"cpp", sesi:"8. MEMORY & ADDRESS DARI OBJECT", url:"https://youtu.be/4wWobjVejnU"},
{category:"cpp", sesi:"9. DESTRUCTOR & OBJECT LIFETIME", url:"https://youtu.be/d2n2R7u_N2c"},
{category:"cpp", sesi:"10. NAMESPACE VS THIS", url:"https://youtu.be/8lqBfkBMeUc"},
{category:"cpp", sesi:"11. PROTOTYPE", url:"https://youtu.be/z0EDi6cpPFc"},
{category:"cpp", sesi:"12. MULTI FILE", url:"https://youtu.be/_5bkDspzmMg"},
{category:"cpp", sesi:"13. PUBLIC & PRIVATE KEYWORD", url:"https://youtu.be/27hvccWDnHc"},
{category:"cpp", sesi:"14. GETTER & SETTER (Encapsulasi)", url:"https://youtu.be/j3cCZMP7J3A"},
{category:"cpp", sesi:"15. LATIHAN ENCAPSULASI", url:"https://youtu.be/9gSgwJsSl3w"},
{category:"cpp", sesi:"16. DEFAULT ASSIGNMENT", url:"https://youtu.be/tbecMtDlgnI"},
{category:"cpp", sesi:"17. CONST OBJECT & METHODS", url:"https://youtu.be/j85kmEjfmsc"},
{category:"cpp", sesi:"18. FRIEND FUNCTION", url:"https://youtu.be/lrPg3LtNae0"},
{category:"cpp", sesi:"19. FRIEND CLASS", url:"https://youtu.be/CuPcnpgPebE"},
{category:"cpp", sesi:"20. THIS & CASCADE FUNCTION CALLS", url:"https://youtu.be/9C03NT254rA"},
{category:"cpp", sesi:"21. STATIC CLASS MEMBER", url:"https://youtu.be/-qf1utdqmYo"},
{category:"cpp", sesi:"22. OPERATOR OVERLOADING", url:"https://youtu.be/Hr3UCHhpbRY"},
{category:"cpp", sesi:"23. STUDI KASUS OPERATOR OVERLOADING", url:"https://youtu.be/EPSOMnEKm9w"},
{category:"cpp", sesi:"24. STUDI KASUS OPERATOR OVERLOADING (Custom Array)", url:"https://youtu.be/sZHi4RIRZjI"},
{category:"cpp", sesi:"25. PENGENALAN INHERITANCE", url:"https://youtu.be/vLNMldfBpww"},
{category:"cpp", sesi:"26. DEEP DIVE INHERITANCE", url:"https://youtu.be/uVmHJtwpiSI"},
{category:"cpp", sesi:"27. VIRTUAL MODIFIER VTABLE & VPTR", url:"https://youtu.be/jV_tCJVdVus"},

/* ================= JAVA (19) ================= */
{category:"java", sesi:"1. PENGENALAN & SEJARAH JAVA", url:"https://youtu.be/XzOwuNX3dIE"},
{category:"java", sesi:"2. PERSIAPAN SOFTWARE", url:"https://youtu.be/7JADsXof_Go"},
{category:"java", sesi:"3. MEMBUAT PROJECT BARU", url:"https://youtu.be/qhDhR2VMCu0"},
{category:"java", sesi:"4. KONSTANTA, VARIABEL & TIPE DATA", url:"https://youtu.be/RHprtsJ_nd0"},
{category:"java", sesi:"5. OPERATOR PADA JAVA", url:"https://youtu.be/4BACEWjhgYo"},
{category:"java", sesi:"6. TEKNIK CASTING PADA JAVA", url:"https://youtu.be/HGC5huFtFj4"},
{category:"java", sesi:"7. IF TUNGGAL DAN IF GANDA", url:"https://youtu.be/p7R7ZTizBOM"},
{category:"java", sesi:"8. SCANNER INPUT / USER INPUT", url:"https://youtu.be/wbKa8avkZfU"},
{category:"java", sesi:"9. IF MAJEMUK PADA JAVA", url:"https://youtu.be/UNbgks8v1DM"},
{category:"java", sesi:"10. PERCABANGAN SWITCH CASE", url:"https://youtu.be/9iidkatIE-4"},
{category:"java", sesi:"11. PERCABANGAN TERNARY DI JAVA", url:"https://youtu.be/YkMHQpxtfYs"},
{category:"java", sesi:"12. PERULANGAN FOR PADA JAVA", url:"https://youtu.be/07R5rMkjz34"},
{category:"java", sesi:"13. PERULANGAN WHILE PADA JAVA", url:"https://youtu.be/FPeZ9_ArSLM"},
{category:"java", sesi:"14. LOOPING DO.WHILE PADA JAVA", url:"https://youtu.be/akdCMKJhByY"},
{category:"java", sesi:"15. MEMBUAT POLA LOOPING DI JAVA", url:"https://youtu.be/EN7polLFXQY"},
{category:"java", sesi:"16. MEMBUAT PROGRAM ATM SEDERHANA", url:"https://youtu.be/SXz0tKrE9BA"},
{category:"java", sesi:"17. ARRAY 1 DIMENSI & 2 DIMENSI PADA BAHASA PEMROGRAMAN JAVA", url:"https://youtu.be/RWIQdAyMzIQ"},
{category:"java", sesi:"18. MEMBUAT POLA MENGGUNAKAN ARRAY 2 DIMENSI & PERULANGAN", url:"https://youtu.be/YYsLzFsKKpk"},
{category:"java", sesi:"19. METHOD, FUNCTION, PROSEDURE PADA BAHASA PEMROGRAMAN JAVA", url:"https://youtu.be/V6GGkqcKY8c"},

/* ================= LARAVEL (17) ================= */
{category:"laravel", sesi:"1. INTRO", url:"https://youtu.be/T1TR-RGf2Pw"},
{category:"laravel", sesi:"2. INSTALASI & KONFIGURASI", url:"https://youtu.be/nW60yGRoUrs"},
{category:"laravel", sesi:"3. STRUKTUR FOLDER", url:"https://youtu.be/x55ndgkD2QI"},
{category:"laravel", sesi:"4. BLADE", url:"https://youtu.be/vDx6VA-6a6Y"},
{category:"laravel", sesi:"5. BLADE COMPONENT", url:"https://youtu.be/00o1vJYTp4I"},
{category:"laravel", sesi:"6. VIEW DATA", url:"https://youtu.be/76YsC4EjGE4"},
{category:"laravel", sesi:"7. MODEL", url:"https://youtu.be/dzjBbvKjbaQ"},
{category:"laravel", sesi:"8. DATABASE & MIGRATION", url:"https://youtu.be/eghZY9-3Wko"},
{category:"laravel", sesi:"9. ELOQUENT ORM", url:"https://youtu.be/dW3-33iMYkk"},
{category:"laravel", sesi:"10. MODEL FACTORIES", url:"https://youtu.be/1wWXyO4iuBA"},
{category:"laravel", sesi:"11. ELOQUENT RELATIONSHIP", url:"https://youtu.be/S2eh1VnHu40"},
{category:"laravel", sesi:"12. POST CATEGORY", url:"https://youtu.be/jineNX34OYE"},
{category:"laravel", sesi:"13. DATABASE SEEDER", url:"https://youtu.be/rAv8C0Nf9uk"},
{category:"laravel", sesi:"14. N+1 PROBLEM", url:"https://youtu.be/K2p6Mtz5P20"},
{category:"laravel", sesi:"15. REDESIGN UI", url:"https://youtu.be/uVRN9DzUAU8"},
{category:"laravel", sesi:"16. SEARCHING", url:"https://youtu.be/8hhaAsRFAJs"},
{category:"laravel", sesi:"17. PAGINATION", url:"https://youtu.be/HP3CdxX9oak"},

/* ================= PHP (23) ================= */
{category:"php", sesi:"1. PERSIAPAN LINGKUNGAN PENGEMBANGAN", url:"https://youtu.be/o8oLQVYlpqw"},
{category:"php", sesi:"2. SINTAKS PHP", url:"https://youtu.be/XTrU0GzMfCk"},
{category:"php", sesi:"3. STRUKTUR KENDALI PADA PHP", url:"https://youtu.be/9gpAJPWD-xI"},
{category:"php", sesi:"4. FUNCTION PADA PHP", url:"https://youtu.be/R5C70w2MOkE"},
{category:"php", sesi:"5. ARRAY PADA PHP", url:"https://youtu.be/qp1l7A4xDIc"},
{category:"php", sesi:"6. ASSOCIATIVE ARRAY PADA PHP", url:"https://youtu.be/mNgOuUUp1I0"},
{category:"php", sesi:"7. GET & POST", url:"https://youtu.be/6vG4oO39ivY"},
{category:"php", sesi:"8. DATABASE & MYSQL", url:"https://youtu.be/fxe6qev-bno"},
{category:"php", sesi:"9. PHP & MYSQL", url:"https://youtu.be/gvkr2V-JULE"},
{category:"php", sesi:"10. INSERT & DELETE", url:"https://youtu.be/L-gKceeb61Q"},
{category:"php", sesi:"11. UPDATE", url:"https://youtu.be/wlJ-UvXucpc"},
{category:"php", sesi:"12. SEARCHING", url:"https://youtu.be/K_ldbZMOvGA"},
{category:"php", sesi:"13. UPLOAD", url:"https://youtu.be/Bsdtpx4WUIU"},
{category:"php", sesi:"14. REGISTRASI", url:"https://youtu.be/b2jUL5RDI18"},
{category:"php", sesi:"15. LOGIN", url:"https://youtu.be/2pAApp655es"},
{category:"php", sesi:"16. SESSION", url:"https://youtu.be/PiYKZ65dkqc"},
{category:"php", sesi:"17. COOKIE (Remember Me)", url:"https://youtu.be/maW4kzHrdKQ"},
{category:"php", sesi:"18. PAGINATION", url:"https://youtu.be/Q1xJdoHrTj4"},
{category:"php", sesi:"19. LIVE SEARCHING MENGGUNAKAN AJAX", url:"https://youtu.be/uND-7A6Hpb8"},
{category:"php", sesi:"20. LIVE SEARCHING MENGGUNAKAN JQUERY", url:"https://youtu.be/aS_V-bMATrw"},
{category:"php", sesi:"21. PDF REPORTING", url:"https://youtu.be/C9Tj7EBrtFo"},
{category:"php", sesi:"22. WEB HOSTING & DOMAIN NAME GRATIS", url:"https://youtu.be/7Sz-iHBcXHo"},
{category:"php", sesi:"23. WEB HOSTING & DOMAIN NAME BERBAYAR", url:"https://youtu.be/7N8MDUJbrRU"}

];

/* ================= CATEGORY LIST ================= */
const categories = [
  {id:"frontend", name:"HTML, CSS, JS"},
  {id:"react", name:"React"},
  {id:"node", name:"Node.js"},
  {id:"python", name:"Python"},
  {id:"cpp", name:"C++"},
  {id:"java", name:"Java"},
  {id:"laravel", name:"Laravel"},
  {id:"php", name:"PHP"}
];

/* ================= HELPER ================= */
function getId(url){
  return url.split("youtu.be/")[1]?.split("?")[0];
}

function toEmbed(url){
  return "https://www.youtube.com/embed/" + getId(url);
}

function getCategory(){
  return new URLSearchParams(window.location.search).get("cat");
}

/* ================= OBSERVER ================= */
const observer = new IntersectionObserver(entries=>{
  entries.forEach(entry=>{
    if(entry.isIntersecting){
      entry.target.classList.add("show");
    }
  });
},{threshold:0.1});

/* ================= RENDER VIDEO ================= */
function renderVideos(list){
  const el = document.getElementById("videos");
  if(!el) return;

  el.innerHTML="";
  for(let i=0;i<6;i++){
    el.innerHTML += `<div class="card skeleton" style="height:140px;"></div>`;
  }

  setTimeout(()=>{
    el.innerHTML="";

    list.forEach(v=>{
      const card=document.createElement("div");
      card.className="card hidden";

      card.innerHTML = `
  <div class="thumb">
    <img src="https://img.youtube.com/vi/${getId(v.url)}/hqdefault.jpg">
    <div class="overlay"></div>
    <div class="play-btn">
      ▶
    </div>
  </div>
  <div class="info">
    <p>${v.sesi}</p>
  </div>
`;
      console.log(card.innerHTML);

      card.onclick=()=>openModal(toEmbed(v.url));

      el.appendChild(card);
      observer.observe(card);
    });

  },500);
}

/* ================= RENDER CATEGORY ================= */
function renderCategories(){
  const el = document.getElementById("categories");
  if(!el) return;

  el.innerHTML="";

  categories.forEach(cat=>{
    const div=document.createElement("div");
    div.className="category hidden";

    div.innerHTML=`<h3>${cat.name}</h3>`;

    div.onclick=()=>{
      window.location.href=`videos.html?cat=${cat.id}`;
    };

    el.appendChild(div);
    observer.observe(div);
  });
}

/* ================= MODAL ================= */
window.openModal=function(url){
  document.getElementById("modal").style.display="block";
  document.getElementById("frame").src=url;
}

window.closeModal=function(){
  document.getElementById("modal").style.display="none";
  document.getElementById("frame").src="";
}

/* ================= INIT ================= */
const cat = getCategory();

if(cat){
  renderVideos(videos.filter(v=>v.category===cat));
}else{
  renderCategories();
}

};