// ============================
// MODULE GALERI
// ============================
// FIX: Import db & storage dengan benar (named export)

import { db }      from "../firebase/db.js";
import { storage } from "../firebase/storage.js";

// init galeri
export function initGallery() {
  const input    = document.getElementById("upload");
  const dropZone = document.getElementById("uploadZone");

  if (!input) return;

  input.addEventListener("change", upload);

  // FIX: Drag & drop support
  if (dropZone) {
    dropZone.addEventListener("dragover", (e) => {
      e.preventDefault();
      dropZone.classList.add("drag-over");
    });

    dropZone.addEventListener("dragleave", () => {
      dropZone.classList.remove("drag-over");
    });

    dropZone.addEventListener("drop", async (e) => {
      e.preventDefault();
      dropZone.classList.remove("drag-over");
      const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith("image/"));
      await uploadFiles(files);
    });
  }

  loadGallery();
}

// upload handler dari input
async function upload(e) {
  const files = Array.from(e.target.files);
  await uploadFiles(files);
  e.target.value = ""; // Reset input
}

// upload files ke storage
async function uploadFiles(files) {
  if (!files.length) return;

  const container = document.getElementById("gallery");
  if (container) {
    container.innerHTML += "<p style='opacity:.6;padding:.5rem;font-size:.85rem;'>Mengupload...</p>";
  }

  try {

    for (const file of files) {
      const timestamp = Date.now();
      const safeName  = file.name.replace(/[^a-zA-Z0-9.-]/g, "_");
      const ref = storage.ref("gallery/" + timestamp + "_" + safeName);

      await ref.put(file);
      const url = await ref.getDownloadURL();

      await db.collection("gallery").add({
        url,
        name:      file.name,
        uploadedAt: firebase.firestore.FieldValue.serverTimestamp()
      });
    }

    await loadGallery();

  } catch (err) {
    console.error("Upload error:", err);
    alert("Gagal upload: " + err.message);
  }
}

// tampilkan galeri
export async function loadGallery() {

  const container = document.getElementById("gallery");
  if (!container) return;

  container.innerHTML = "";

  try {

    const data = await db
      .collection("gallery")
      .orderBy("uploadedAt", "desc")
      .get();

    if (data.empty) {
      container.innerHTML = "<p style='opacity:.4;padding:1rem;text-align:center;'>Belum ada foto. Upload dulu!</p>";
      return;
    }

    data.forEach(doc => {
      const img = document.createElement("img");
      img.src   = doc.data().url;
      img.alt   = doc.data().name || "Gallery";
      img.loading = "lazy";
      img.style.cssText = "width:100%;height:200px;object-fit:cover;border-radius:8px;cursor:pointer;";

      // FIX: Click untuk buka full screen
      img.addEventListener("click", () => {
        window.open(doc.data().url, "_blank");
      });

      container.appendChild(img);
    });

  } catch (err) {
    // FIX: Jika orderBy gagal (index belum ada), fallback tanpa orderBy
    if (err.code === "failed-precondition") {
      const data = await db.collection("gallery").get();
      data.forEach(doc => {
        const img = document.createElement("img");
        img.src   = doc.data().url;
        img.alt   = "Gallery";
        img.loading = "lazy";
        img.style.cssText = "width:100%;height:200px;object-fit:cover;border-radius:8px;";
        container.appendChild(img);
      });
    } else {
      console.error("loadGallery error:", err);
      container.innerHTML = "<p style='color:red;padding:1rem;'>Gagal memuat gallery: " + err.message + "</p>";
    }
  }

}
