// ============================
// MODULE ABSENSI
// ============================
// FIX: Import db dengan benar (named export)

import { db } from "../firebase/db.js";

// load absensi
export async function loadAbsensi(role = "siswa") {

  const dateEl  = document.getElementById("date");
  const container = document.getElementById("absenList");

  if (!dateEl || !container) return;

  const date = dateEl.value;
  if (!date) return;

  container.innerHTML = "<div class='loader'></div>";

  try {

    const users = await db.collection("users").get();
    container.innerHTML = "";

    // Hitung statistik
    let masukCount = 0, alfaCount = 0, disCount = 0;

    for (const user of users.docs) {

      const u = user.data();

      const record = await db
        .collection("attendance")
        .doc(date)
        .collection("records")
        .doc(user.id)
        .get();

      const status = record.exists ? record.data().status : "-";

      // Hitung statistik
      if (status === "masuk")       masukCount++;
      else if (status === "alfa")   alfaCount++;
      else if (status === "dispensasi") disCount++;

      const div = document.createElement("div");
      div.className = "item";

      div.innerHTML = `
        <span>${u.name || u.email || user.id}</span>
        ${
          role === "admin"
            ? `<select onchange="setAbsen('${user.id}','${(u.name || u.email || user.id).replace(/'/g, "\\'")}',this.value)">
                <option value="">--</option>
                <option ${status === "masuk"       ? "selected" : ""} value="masuk">Masuk</option>
                <option ${status === "alfa"        ? "selected" : ""} value="alfa">Alfa</option>
                <option ${status === "dispensasi"  ? "selected" : ""} value="dispensasi">Dispensasi</option>
              </select>`
            : `<b>${status}</b>`
        }
      `;

      container.appendChild(div);
    }

    // FIX: Update dashboard stats
    const totalSiswa   = document.getElementById("totalSiswa");
    const hadirHariIni = document.getElementById("hadirHariIni");
    const alfaHariIni  = document.getElementById("alfaHariIni");
    const disHariIni   = document.getElementById("disHariIni");

    if (totalSiswa)   totalSiswa.textContent   = users.size;
    if (hadirHariIni) hadirHariIni.textContent  = masukCount;
    if (alfaHariIni)  alfaHariIni.textContent   = alfaCount;
    if (disHariIni)   disHariIni.textContent    = disCount;

  } catch (err) {
    console.error("loadAbsensi error:", err);
    container.innerHTML = "<p style='color:red;padding:1rem;'>Gagal memuat absensi: " + err.message + "</p>";
  }

}

// set absensi
export async function setAbsen(id, name, status) {

  const date = document.getElementById("date").value;

  try {

    await db
      .collection("attendance")
      .doc(date)
      .collection("records")
      .doc(id)
      .set({ name, status });

    loadAbsensi("admin");

    if (window.app && window.app.reloadRekap) {
      window.app.reloadRekap();
    }

  } catch (err) {
    alert("Gagal simpan absensi: " + err.message);
  }

}

window.setAbsen = setAbsen;
