// ============================
// MODULE UI
// ============================

// toggle dark/light
export function toggleTheme() {
  document.body.classList.toggle("light");
}