// ============================
// MODULE REKAP
// ============================
// FIX: Import db dengan benar (named export)

import { db } from "../firebase/db.js";

export async function loadRekap() {

  const container = document.getElementById("rekap");
  if (!container) return;

  container.innerHTML = "<div class='loader'></div>";

  try {

    const users = await db.collection("users").get();
    const dates = await db.collection("attendance").get();

    container.innerHTML = "";

    for (const user of users.docs) {

      let masuk = 0, alfa = 0, dis = 0;

      for (const d of dates.docs) {

        const rec = await db
          .collection("attendance")
          .doc(d.id)
          .collection("records")
          .doc(user.id)
          .get();

        if (rec.exists) {
          const s = rec.data().status;
          if (s === "masuk")       masuk++;
          if (s === "alfa")        alfa++;
          if (s === "dispensasi")  dis++;
        }

      }

      const div = document.createElement("div");
      div.className = "item";

      const name = user.data().name || user.data().email || user.id;
      div.innerHTML = `
        <span>${name}</span>
        <span style="color:var(--success)">M: ${masuk}</span>
        <span style="color:var(--danger)">A: ${alfa}</span>
        <span style="color:var(--warning)">D: ${dis}</span>
      `;

      container.appendChild(div);
    }

    if (users.empty) {
      container.innerHTML = "<p style='opacity:.5;padding:1rem;'>Belum ada data siswa.</p>";
    }

  } catch (err) {
    console.error("loadRekap error:", err);
    container.innerHTML = "<p style='color:red;padding:1rem;'>Gagal memuat rekap: " + err.message + "</p>";
  }

}
