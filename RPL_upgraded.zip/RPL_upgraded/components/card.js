// ============================
// CARD COMPONENT
// ============================

export function createCard(title, content) {

  const card = document.createElement("div");
  card.className = "card";

  card.innerHTML = `
    <h3>${title}</h3>
    <div>${content}</div>
  `;

  return card;
}