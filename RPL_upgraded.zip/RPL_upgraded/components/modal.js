// ============================
// MODAL
// ============================

export function showAlert(msg) {
  alert(msg);
}