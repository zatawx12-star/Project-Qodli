// ============================
// NAVBAR — UPGRADED
// ============================

import { toggleTheme } from "../modules/ui.js";

export function renderNavbar(role, logout) {

  const nav = document.getElementById("navbar");

  nav.innerHTML = `
    <div class="nav-left">
      <div class="nav-logo">
        <div class="nav-logo-icon">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#00ff88" stroke-width="2.5" stroke-linecap="round">
            <path d="M8 6L4 12L8 18"/>
            <path d="M16 6L20 12L16 18"/>
          </svg>
        </div>
        <span class="nav-logo-text">RPL<span class="accent-text">_</span>System</span>
      </div>
      ${role === "admin" ? '<span class="admin-badge">ADMIN</span>' : ''}
    </div>
    <div class="nav-right">
      <span class="user-info">● online</span>
      <button id="theme" title="Toggle Theme">⬡ Theme</button>
      <button id="logout" title="Logout">⏻ Logout</button>
    </div>
  `;

  document.getElementById("logout").onclick = logout;
  document.getElementById("theme").onclick = toggleTheme;
}
