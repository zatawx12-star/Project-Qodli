// ============================
// MAIN CONTROLLER
// ============================

// auth
import {
  initAuth,
  login,
  logout,
  register
} from "./firebase/auth.js";

// modules
import { loadAbsensi } from "./modules/absensi.js";
import { loadRekap }   from "./modules/rekap.js";
import { initGallery } from "./modules/gallery.js";

// components
import { renderNavbar } from "./components/navbar.js";

// utils
import { setToday } from "./utils/date.js";

// ============================
// WAIT DOM
// ============================
window.addEventListener("DOMContentLoaded", () => {

  // ============================
  // FIX: Pastikan Firebase SDK global sudah siap
  // Firebase compat scripts pakai `defer` di HTML,
  // tapi module ini juga defer — urutan tidak dijamin.
  // Solusi: polling sampai firebase tersedia.
  // ============================
  function waitForFirebase(cb, retries = 20) {
    if (window.firebase && firebase.apps !== undefined) {
      cb();
    } else if (retries > 0) {
      setTimeout(() => waitForFirebase(cb, retries - 1), 100);
    } else {
      console.error("Firebase gagal dimuat setelah 2 detik.");
      alert("Gagal memuat Firebase. Refresh halaman atau cek koneksi internet.");
    }
  }

  waitForFirebase(() => {

    // ============================
    // INIT AUTH
    // ============================
    initAuth(async (user, role) => {

      if (user) {

        // Tampilkan app
        document.getElementById("loginPage").style.display = "none";
        document.getElementById("app").style.display       = "block";

        // Navbar
        renderNavbar(role, logout);

        // Set tanggal hari ini
        setToday();

        // Load fitur
        await loadAbsensi(role);
        await loadRekap();
        initGallery();

        // FIX: Load absensi setelah tanggal diset
        await loadAbsensi(role);

      } else {

        // Tampilkan login
        document.getElementById("loginPage").style.display = "flex";
        document.getElementById("app").style.display       = "none";

      }

    });

    // ============================
    // LOGIN BUTTON
    // ============================
    const loginBtn = document.getElementById("loginBtn");
    if (loginBtn) {
      loginBtn.addEventListener("click", async () => {
        loginBtn.disabled    = true;
        loginBtn.textContent = "Loading...";
        try {
          await login();
        } catch (err) {
          console.error(err);
        } finally {
          loginBtn.disabled = false;
          loginBtn.innerHTML = '<span class="btn-icon">▶</span><span>./login.sh</span>';
        }
      });
    }

    // ============================
    // REGISTER BUTTON
    // ============================
    const registerBtn = document.getElementById("registerBtn");
    if (registerBtn) {
      registerBtn.addEventListener("click", async () => {
        registerBtn.disabled    = true;
        registerBtn.textContent = "Loading...";
        try {
          await register();
        } catch (err) {
          console.error(err);
        } finally {
          registerBtn.disabled    = false;
          registerBtn.textContent = "git init user";
        }
      });
    }

    // ============================
    // DATE CHANGE
    // ============================
    const dateInput = document.getElementById("date");
    if (dateInput) {
      dateInput.addEventListener("change", () => {
        // Ambil role dari state
        const isAdmin = document.querySelector(".admin-badge") !== null;
        loadAbsensi(isAdmin ? "admin" : "siswa");
      });
    }

  }); // end waitForFirebase

}); // end DOMContentLoaded

// ============================
// GLOBAL HELPERS
// ============================
window.app = {
  reloadAbsensi: loadAbsensi,
  reloadRekap:   loadRekap
};
