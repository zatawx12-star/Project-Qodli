// ============================
// CONFIG FIREBASE
// ============================
// FIX: Tidak pakai export — Firebase compat SDK
// diinisialisasi via script global di index.html.
// Config disimpan di window supaya semua module bisa akses.

window._firebaseConfig = {
  apiKey: "AIzaSyCp0AG8-asSjERc_sS6sVjUgFJuAhtzmJA",
  authDomain: "kelas-f2273.firebaseapp.com",
  projectId: "kelas-f2273",
  storageBucket: "kelas-f2273.firebasestorage.app",
  messagingSenderId: "15319684009",
  appId: "1:15319684009:web:74056b5812530c47cdeab8",
  measurementId: "G-NDZ9ZHL8K1"
};