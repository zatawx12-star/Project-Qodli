// ============================
// FIREBASE AUTH
// ============================
// FIX: Hapus import firebaseConfig yang salah.
// Firebase compat SDK sudah diinit via script di index.html.
// Cukup pakai firebase global langsung.

function getAuth() {
  if (!window.firebase) {
    throw new Error("Firebase SDK belum dimuat.");
  }
  if (!firebase.apps.length) {
    firebase.initializeApp(window._firebaseConfig);
  }
  return firebase.auth();
}

// ============================
// INIT AUTH
// ============================
export function initAuth(callback) {
  const auth = getAuth();

  auth.onAuthStateChanged(async (user) => {
    if (user) {
      // Cek role dari Firestore
      try {
        const db = firebase.firestore();
        const doc = await db.collection("users").doc(user.uid).get();
        const role = doc.exists && doc.data().role === "admin" ? "admin" : "siswa";
        callback(user, role);
      } catch (e) {
        callback(user, "siswa");
      }
    } else {
      callback(null, null);
    }
  });
}

// ============================
// LOGIN
// ============================
export async function login() {
  const email    = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  if (!email || !password) {
    alert("Isi email dan password terlebih dahulu!");
    return;
  }

  try {
    const auth = getAuth();
    await auth.signInWithEmailAndPassword(email, password);
  } catch (err) {
    const msg = friendlyError(err.code);
    alert("Login gagal: " + msg);
  }
}

// ============================
// REGISTER
// ============================
export async function register() {
  const email    = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  if (!email || !password) {
    alert("Isi email dan password terlebih dahulu!");
    return;
  }

  if (password.length < 6) {
    alert("Password minimal 6 karakter!");
    return;
  }

  try {
    const auth = getAuth();
    const cred = await auth.createUserWithEmailAndPassword(email, password);

    // Simpan data user ke Firestore
    const db = firebase.firestore();
    await db.collection("users").doc(cred.user.uid).set({
      email: email,
      name: email.split("@")[0],
      role: "siswa",
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    alert("Register berhasil! Selamat datang.");
  } catch (err) {
    const msg = friendlyError(err.code);
    alert("Register gagal: " + msg);
  }
}

// ============================
// LOGOUT
// ============================
export async function logout() {
  const auth = getAuth();
  await auth.signOut();
}

// ============================
// HELPER: Pesan error ramah
// ============================
function friendlyError(code) {
  const messages = {
    "auth/user-not-found":         "Email tidak ditemukan.",
    "auth/wrong-password":         "Password salah.",
    "auth/invalid-email":          "Format email tidak valid.",
    "auth/email-already-in-use":   "Email sudah terdaftar.",
    "auth/weak-password":          "Password terlalu lemah (min. 6 karakter).",
    "auth/network-request-failed": "Gagal terhubung ke internet.",
    "auth/too-many-requests":      "Terlalu banyak percobaan. Coba lagi nanti.",
    "auth/invalid-credential":     "Email atau password salah.",
  };
  return messages[code] || "Terjadi kesalahan. Silakan coba lagi.";
}
