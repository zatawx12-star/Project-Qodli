// ============================
// FIRESTORE DB
// ============================
// FIX: Hapus import firebaseConfig yang salah (tidak kompatibel dengan compat SDK).
// Gunakan firebase global yang sudah diinit oleh script di index.html.

function initFirebase() {
  if (!firebase.apps.length) {
    firebase.initializeApp(window._firebaseConfig);
  }
}

initFirebase();

// FIX: Export sebagai named export agar konsisten dengan semua import
export const db = firebase.firestore();

// FIX: Juga export sebagai default untuk backward compat
export default db;
