// ============================
// FIREBASE STORAGE
// ============================
// FIX: Hapus import firebaseConfig yang salah.
// Gunakan firebase global compat SDK.

function initFirebase() {
  if (!firebase.apps.length) {
    firebase.initializeApp(window._firebaseConfig);
  }
}

initFirebase();

export const storage = firebase.storage();
export default storage;
