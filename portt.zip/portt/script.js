gsap.registerPlugin(ScrollTrigger);

/* SIDEBAR */
const menu = document.getElementById("menu-icon");
const sidebar = document.getElementById("sidebar");
const overlay = document.querySelector(".overlay");

menu.onclick = ()=>{
  gsap.to("#sidebar",{x:0,duration:0.5});
  gsap.to(".overlay",{opacity:1,pointerEvents:"auto"});
};

overlay.onclick = ()=>{
  gsap.to("#sidebar",{x:"100%",duration:0.4});
  gsap.to(".overlay",{opacity:0,pointerEvents:"none"});
};

/* ANIMASI HOME */
gsap.from(".home-img img",{scale:0.8,opacity:0,duration:1});
gsap.from(".home-content",{y:50,opacity:0,duration:1});

/* SKILL ANIMATION + COUNT */
gsap.utils.toArray(".bar span").forEach((bar, i)=>{
  let value = parseInt(bar.dataset.width);
  let percent = document.querySelectorAll(".percent")[i];

  let obj = {val:0};

  gsap.to(bar,{
    width:value + "%",
    duration:1.5,
    ease:"power3.out",
    scrollTrigger:{
      trigger:bar,
      start:"top 85%"
    }
  });

  gsap.to(obj,{
    val:value,
    duration:1.5,
    ease:"power3.out",
    scrollTrigger:{
      trigger:bar,
      start:"top 85%"
    },
    onUpdate:()=>{
      percent.textContent = Math.floor(obj.val) + "%";
    }
  });
});